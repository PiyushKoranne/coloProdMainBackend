const mongoose = require("mongoose");

const CustomizationSchema = new mongoose.Schema({
	protalProviderWelcomeMessage: String,
	paperProviderWelcomeMessage: String,
	portalWelcomePDF: String,
	paperWelcomePDF: String,
})

const customizationModel = mongoose.model("Customization", CustomizationSchema);

module.exports = customizationModel;
